public class Task51 {
    public static void main(String[] args) {
        Square square = new Square(2, 2);
        Square rectangle = new Square(3, 4); // That's a feauture ;) And also we may use that for triangle !!!
        Triangle triangle = new Triangle(3, 4, 30);  //30dg=1/2; 90dg=1 0dg=0
        Circle circle = new Circle(2);
        System.out.println("Squares's area is: " + square.getArea());
        System.out.println("Rectangle's area is: " + rectangle.getArea());
        System.out.println("Triangle's area is: " + triangle.getArea());
        System.out.println("Circles's area is: " + circle.getArea());
    }
}
