public class Circle extends Figure {

    private double radius;
    // private double  pi=3.14;

    public Circle(double radius) {
        this.radius = radius;
    }


    @Override
    public double getArea() {
        //return radius*radius *pi;
        return Math.pow(radius, 2) * Math.PI;
    }
}