public class Triangle extends Figure {

    private double side1;
    private double side2;
    private int angle;

    public Triangle(double side1, double side2, int angle) {
        this.side1 = side1;
        this.side2 = side2;
        this.angle = angle;
    }

    @Override
    public double getArea() {
        return side1 * side2 * Math.ceil(Math.sin(angle * Math.PI / 180)) / 2;  //convert angle to radians
    }
}
