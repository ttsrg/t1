public abstract class Figure {

   /* private int width;
    private  int height;

    public Figure(int width, int height) {
        this.width = width;
        this.height = height;
    }                                                   //May we use with same figurs?

    public void getParameters(){
        System.out.println("");
    }*/

    public abstract double getArea();

}

