#!/bin/bash
javac -sourcepath src src/Task51.java  -d out/

java -cp out/ Task51