import java.util.Scanner;

public class InputArray {


    public static int scan() {
        Scanner input = new Scanner(System.in);

        int number = input.nextInt();
        return number;
    }
}
