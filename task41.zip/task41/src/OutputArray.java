import java.util.Arrays;

public class OutputArray {
    static void output(int arrayI, int i) {

        i++;
        //return new int[4];
        System.out.print("value:" + i + "=" + arrayI + "\t|\t");
    }
    //System.out.print(Arrays.toString(output()));  ??????

}

